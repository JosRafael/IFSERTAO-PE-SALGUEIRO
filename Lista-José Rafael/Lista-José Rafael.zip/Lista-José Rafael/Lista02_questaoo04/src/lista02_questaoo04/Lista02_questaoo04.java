package lista02_questaoo04;


public class Lista02_questaoo04 {

  
    public static void main(String[] args) {
        Janela app = new Janela();
    }
    
}
