package lista02_questaoo04;

import javax.swing.event.ListSelectionEvent;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Janela extends JFrame {

    private final JLabel lab1;
    private final JLabel lab2;
    private JList list;
    private JComboBox<Integer> jComboBox;
    private JTextArea area;
    private String a = "";
    private final JPanel painel;
    public Janela(){
        
       
        
        super("");
        this.setLayout(new FlowLayout());

        painel = new JPanel();
        painel.setLayout(new BorderLayout());


        System.out.println("OPERAÇÕES: ");
        String[] opera = 
        {
            "Soma", "Subtração", "Multiplicação", "Divisão"};
        list = new JList(opera);
        Component add1 = this.add(list);
        

        lab2 = new JLabel("Tabuada de:");
        Component add2 = this.add(lab2);
        Integer[] tabuada = {1,2,3,4,5,6,7,8,9,10};
        jComboBox = new JComboBox<>(tabuada);
        Component add3 = add(jComboBox);
        

        list.addListSelectionListener((var e) -> {
            if (e.getValueIsAdjusting() == true) {
             
                if (list.getSelectedValue() == "Soma") {
                    area.setText("");
                    for (int i = 0; i < 10; i++) {
                        int soma = i + (jComboBox.getSelectedIndex() + 1);
                        a = (i + " + " + (jComboBox.getSelectedIndex() + 1) + " = " + soma + "\n");
                        area.append(a);
                        
                    }
                }
            }
        });
        area = new JTextArea();
        Component add4 = add(area);

        list.addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting() == true) {
          
                if (list.getSelectedValue() == "Subtração") {
                    area.setText("");
                    for (int i = 0; i < 10; i++) {
                        int sub = i - (jComboBox.getSelectedIndex() + 1);
                        a = (i + " - " + (jComboBox.getSelectedIndex() + 1) + " = " + sub + "\n");
                        area.append(a);
                    }
                 
                }
            }
        });
        add(area);
        

        list.addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting() == true) {
            
                if(list.getSelectedValue() == "Multiplicação") {
                    area.setText("");
                    for (int i = 0; i < 10; i++) {
                        int mult = i * (jComboBox.getSelectedIndex() + 1);
                        a = (i + " * " + (jComboBox.getSelectedIndex() + 1) + " = " + mult + "\n");
                        area.append(a);
                    }
               
                }
            }
        });
        add(area);

        list.addListSelectionListener((ListSelectionEvent e) -> {
            if (e.getValueIsAdjusting() == true) {
         
                if (list.getSelectedValue() == "Divisão") {
                    area.setText("");
                    for (int i = 0; i < 10; i++) {
                        double div = i / (jComboBox.getSelectedIndex() + 1);
                        a = (i + " / " + (jComboBox.getSelectedIndex() + 1) + " = " + div + "\n");
                        area.append(a);
                    }
                  
                }
            }
        });
        add(area);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setSize(300,400);

    
    }
}

