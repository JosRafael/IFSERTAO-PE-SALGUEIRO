
package lista02_questao03;


public class Lista02_questao03 {

   
    public static void main(String[] args) {
        Janela app = new Janela();
    }
    
}
