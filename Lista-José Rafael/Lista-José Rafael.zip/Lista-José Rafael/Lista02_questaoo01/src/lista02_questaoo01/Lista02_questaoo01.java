package lista02_questaoo01;

import java.util.Arrays;

public class Lista02_questaoo01 {

    public static void main(String[] args) {
        
        String[] produtos = {"Fortnite", "O poderoso Chefão", "Bruno e Marrone", "Ilha do medo", "Noiva cadaver", "Titanic", "Orlando", "Jõao"};
        System.out.println(Arrays.toString(produtos));
        
        Produtos produto1 = new Produtos(85201);
        Produtos produto2 = new Produtos(85258);
        
        
        produto1.procurarProd(produtos[0], produtos);
        produto1.procurarProd(produtos[2], produtos);
        
        
        if(produto1.codBarras.equals(produto2.codBarras)){
            System.out.println("CÓD DE BARRAS: IGUAL(=)");
        }
        else{
           
            System.out.println("\nCÓD DE BARRAS: NÃO IGUAL(#=)");
        }
        
    }

}
