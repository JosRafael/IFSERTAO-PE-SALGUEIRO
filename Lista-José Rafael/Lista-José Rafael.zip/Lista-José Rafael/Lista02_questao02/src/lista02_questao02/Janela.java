package lista02_questao02;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Janela extends JFrame{
   
    private JTextField jText = new JTextField();
    private JButton but = new JButton();
      private int contador = 0;
    
    public Janela(){
        super("Cliques");
        
        but = new JButton("CLIQUES");
        but.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    contador++;
                    jText.setText("" + contador);
                }
            }
        );
        add(but);
      
        jText = new JTextField(10);
        add(jText);
        
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setSize(250, 100);
    }
}

