
package lista02_questao02;


public class Lista02_questao02 {

    
    public static void main(String[] args) {
       Janela app = new Janela();
    }
    
}
